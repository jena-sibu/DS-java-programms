// 1. Read Number From Standard Input

import java.util.Scanner;

public class j1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        System.out.println("You entered: " + number);
    }
}