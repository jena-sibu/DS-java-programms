// 6. Add Two Complex Numbers

public class j6 {
    public static void main(String[] args) {
        double real1 = 1.2, imaginary1 = 2.3;
        double real2 = 3.4, imaginary2 = 4.5;
        double realResult = real1 + real2;
        double imaginaryResult = imaginary1 + imaginary2;
        System.out.println("Sum: " + realResult + " + " + imaginaryResult + "i");
    }
}