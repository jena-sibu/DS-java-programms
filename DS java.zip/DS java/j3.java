// 3. Multiply Two Floating-Point Numbers

import java.util.Scanner;

public class j3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double num1 = sc.nextDouble();
        double num2 = sc.nextDouble();
        System.out.println("Product: " + (num1 * num2));
    }
}